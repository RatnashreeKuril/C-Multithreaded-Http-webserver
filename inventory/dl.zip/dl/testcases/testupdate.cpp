#include<iostream>
#include<uom>
#include<iuom>
#include<uomdao> 
using namespace inventory;
using namespace data_layer;
int main()
{
UnitOfMeasurementDAO unitOfMeasurementDAO;
UnitOfMeasurement unitOfMeasurement;
try
{
unitOfMeasurementDAO.update(&unitOfMeasurement);
}catch(DAOException daoException)
{
cout<<daoException.what();
}
return 0;
}