#include<dl/iuomdao>
using namespace inventory;
using namespace data_layer;
string abc::IUnitOfMeasurementDAO::FILE_NAME="uom.dat";